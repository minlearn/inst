@echo -off
map -r

if exist fs0:\EFI\Microsoft\Boot\bootmgfw.original.efi then
  fs0:\EFI\Microsoft\Boot\bootmgfw.original.efi
endif
if exist fs1:\EFI\Microsoft\Boot\bootmgfw.original.efi then
  fs1:\EFI\Microsoft\Boot\bootmgfw.original.efi
endif

if exist fs3:\efi\boot\bootx64.efi then
  fs3:\efi\boot\bootx64.efi
endif
