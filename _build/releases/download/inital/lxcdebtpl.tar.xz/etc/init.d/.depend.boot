TARGETS = hwclock.sh networking
INTERACTIVE =
