<!doctype html>
<html>
    <head>
	<title>[% nodename %] - Proxmox Console</title>
	<link rel="stylesheet" href="/xtermjs/xterm.css?version=4.16.0-1" />
	<link rel="stylesheet" href="/xtermjs/style.css?version=4.16.0-1" />
	<script src="/xtermjs/xterm.js?version=4.16.0-1" ></script>
	<script src="/xtermjs/xterm-addon-fit.js?version=4.16.0-1" ></script>
	<script src="/xtermjs/util.js?version=4.16.0-1" ></script>
    </head>
    <body>
	<div id="status_bar"></div>
	<div id="wrap">
	<div class="center">
	    <div id="connect_dlg">
		<div id="pve_start_info">Guest not running</div>
		<div id="connect_btn"><div> Start Now </div></div>
	    </div>
	</div>
	<div id="terminal-container"></div>
	</div>
	<script type="text/javascript">
	    if (typeof(PVE) === 'undefined') PVE = {};
	    PVE.UserName = '[% username %]';
	    PVE.CSRFPreventionToken = '[% token %]';
	</script>
	<script src="/xtermjs/main.js?version=4.16.0-1" defer ></script>
    </body>
</html>
